<div id="content">

 
<?php echo form_open('c=home&m=restartCgminer'); ?>

<input name="restart" value="restart Cgminer" type="submit"   class="btn btn-large 	btn-primary">
 
<?php echo form_close(); ?>

</div>